PDRTJS_4910994_post_606.avg_rating = 0;
PDRTJS_4910994_post_606.votes = 0;		
PDRTJS_settings_4910994_post_606= {
			"type" : "stars",
			"size" : "sml",
			"star_color" : "yellow",
			"custom_star" : "",
			"font_size" : "",
			"font_line_height" : "16px",
			"font_color" : "",
			"font_align" : "left",
			"font_position" : "right",
			"font_family" : "",
			"font_bold" : "normal",
			"font_italic" : "normal",
			"text_vote" : "Vote",
			"text_votes" : "Votes",
			"text_rate_this" : "Rate This",
			"text_1_star" : "Very Poor",
			"text_2_star" : "Poor",
			"text_3_star" : "Average",
			"text_4_star" : "Good",
			"text_5_star" : "Excellent",
			"text_thank_you" : "Thank You",
			"text_rate_up" : "Rate Up",
			"text_rate_down" : "Rate Down"
		};
PDRTJS_4910994_post_606.init();		
PDRTJS_4910994_post_606.token='85abe7648ff48045bbb26fbff4b51e86';
/*4910994,_post_606,wp-post-606,1165355893,0-0*/